window.onload = function(){
    var userPlus = document.getElementById("addUser");
    var addModal = document.getElementById("modalAddUser");
    
    userPlus.addEventListener("click", () => {
        addModal.classList.add("show");
        addModal.style.display = "block";
    })
    
    window.addEventListener("click", (event)=> {
        if (event.target == addModal) {
          addModal.style.display = "none";
        }
    });
    
};

function editUser(){
    var userPlus = document.getElementById("addUser");
    var addModal = document.getElementById("modalAddUser");
    addModal.classList.add("show");
    addModal.style.display = "block";
}

function deleteUser(){
    var modal = document.getElementById("deleteModal");
    modal.classList.add("show");
    modal.style.display = "block";
    var cancelDelete=document.querySelectorAll(".deleteCancel");
    cancelDelete.forEach((btn)=>{
        btn.addEventListener("click", ()=>{
            modal.style.display = "none";
        });
    });
    
    var confirmDelete = document.querySelector(".confirmDelete");
    confirmDelete.addEventListener("click", ()=>{
        modal.style.display = "none";
    });
}